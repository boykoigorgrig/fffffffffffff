package com.e.systemscalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigInteger;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNumber;
    private EditText editTextRadixNumber;
    private EditText editTextTargetRadix;

    private TextView textViewResult;

    private Button buttonGetResult;
    private Button buttonGoToCalculatorActivity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumber = findViewById(R.id.editTextNumber);
        editTextRadixNumber = findViewById(R.id.editTextRadixNumber);
        editTextTargetRadix = findViewById(R.id.editTextTargetRadix);

        textViewResult = findViewById(R.id.textViewResult);

        buttonGetResult = findViewById(R.id.buttonGetResult);
        buttonGoToCalculatorActivity = findViewById(R.id.buttonGoToCalculatorActivity);

        buttonGetResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (
                        editTextNumber.getText().toString().trim().equals("")||
                        editTextRadixNumber.getText().toString().trim().equals("")||
                        editTextTargetRadix.getText().toString().trim().equals("")
                ){
                    Toast.makeText(getApplicationContext(), "Введите данные!", Toast.LENGTH_SHORT).show();
                }else {
                    String value = editTextNumber.getText().toString().trim();
                    String radix = editTextRadixNumber.getText().toString().trim();
                    String targetRadix = editTextTargetRadix.getText().toString().trim();
                    String s = "0";
                    try {
                        BigInteger a = new BigInteger(value, Integer.parseInt(radix));
                        s = a.toString(Integer.parseInt(targetRadix));
                        Log.d("dasdas", "dasdsa");
                    }catch (NumberFormatException e){
                        Toast.makeText(getApplicationContext(), "Неверное число для данной системы!", Toast.LENGTH_SHORT).show();
                    }
                    textViewResult.setText(s);
                }
            }
        });

        buttonGoToCalculatorActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CalculatorActivity.class);
                startActivity(intent);
            }
        });
    }
}