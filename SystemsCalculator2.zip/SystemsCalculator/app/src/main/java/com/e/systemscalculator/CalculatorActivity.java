package com.e.systemscalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigInteger;

public class CalculatorActivity extends AppCompatActivity {

    private Button buttonPlus;
    private Button buttonMinus;
    private Button buttonDivide;
    private Button buttonMultiply;

    private EditText editTextNumber1Calculator;
    private EditText editTextRadixNumber1Calculator;

    private EditText editTextNumber2Calculator;
    private EditText editTextRadixNumber2Calculator;

    private TextView textViewResultCalculator;

    private EditText editTextTargetRadixCalculator;

    private ImageView imageViewBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        buttonPlus = findViewById(R.id.buttonPlus);
        buttonMinus = findViewById(R.id.buttonMinus);
        buttonDivide = findViewById(R.id.buttonDivide);
        buttonMultiply = findViewById(R.id.buttonMultiply);

        editTextNumber1Calculator = findViewById(R.id.editTextNumber1Calculator);
        editTextRadixNumber1Calculator = findViewById(R.id.editTextRadixNumber1Calculator);

        editTextNumber2Calculator = findViewById(R.id.editTextNumber2Calculator);
        editTextRadixNumber2Calculator = findViewById(R.id.editTextRadixNumber2Calculator);

        textViewResultCalculator = findViewById(R.id.textViewResultCalculator);

        editTextTargetRadixCalculator = findViewById(R.id.editTextTargetRadixCalculator);

        imageViewBack = findViewById(R.id.imageViewBack);


        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        buttonPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkEditTexts()){
                    int firstValue = getFirstValueIn10Radix(editTextNumber1Calculator.getText().toString().trim(), editTextRadixNumber1Calculator.getText().toString().trim());
                    int secondValue = getSecondValueIn10Radix(editTextNumber2Calculator.getText().toString().trim(), editTextRadixNumber2Calculator.getText().toString().trim());

                    int result = getValueInTargetRadix(firstValue + secondValue, editTextTargetRadixCalculator.getText().toString().trim());
                    textViewResultCalculator.setText(String.valueOf(result));

                }
            }
        });

        buttonMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkEditTexts()){
                    int firstValue = getFirstValueIn10Radix(editTextNumber1Calculator.getText().toString().trim(), editTextRadixNumber1Calculator.getText().toString().trim());
                    int secondValue = getSecondValueIn10Radix(editTextNumber2Calculator.getText().toString().trim(), editTextRadixNumber2Calculator.getText().toString().trim());

                    int result = getValueInTargetRadix(firstValue - secondValue, editTextTargetRadixCalculator.getText().toString().trim());
                    textViewResultCalculator.setText(String.valueOf(result));
                }
            }
        });

        buttonDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkEditTexts()){
                    int firstValue = getFirstValueIn10Radix(editTextNumber1Calculator.getText().toString().trim(), editTextRadixNumber1Calculator.getText().toString().trim());
                    int secondValue = getSecondValueIn10Radix(editTextNumber2Calculator.getText().toString().trim(), editTextRadixNumber2Calculator.getText().toString().trim());

                    int result = getValueInTargetRadix(firstValue / secondValue, editTextTargetRadixCalculator.getText().toString().trim());
                    textViewResultCalculator.setText(String.valueOf(result));
                }
            }
        });

        buttonMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkEditTexts()){
                    int firstValue = getFirstValueIn10Radix(editTextNumber1Calculator.getText().toString().trim(), editTextRadixNumber1Calculator.getText().toString().trim());
                    int secondValue = getSecondValueIn10Radix(editTextNumber2Calculator.getText().toString().trim(), editTextRadixNumber2Calculator.getText().toString().trim());

                    int result = getValueInTargetRadix(firstValue * secondValue, editTextTargetRadixCalculator.getText().toString().trim());
                    textViewResultCalculator.setText(String.valueOf(result));
                }
            }
        });
    }

    private boolean checkEditTexts(){
        if (
                editTextNumber1Calculator.getText().toString().trim().equals("")||
                editTextRadixNumber1Calculator.getText().toString().trim().equals("")||
                editTextNumber2Calculator.getText().toString().trim().equals("")||
                editTextRadixNumber2Calculator.getText().toString().trim().equals("")||
                editTextTargetRadixCalculator.getText().toString().trim().equals("")
        ){
            Toast.makeText(getApplicationContext(), "Введите все значения!", Toast.LENGTH_SHORT).show();
            return false;
        }else return true;
    }

    private int getFirstValueIn10Radix(String value, String radix){
        String s = "0";
        try {
            BigInteger a = new BigInteger(value, Integer.parseInt(radix));
            s = a.toString(10);
        }catch (NumberFormatException e){
            Toast.makeText(getApplicationContext(), "Неверное число для данной системы!", Toast.LENGTH_SHORT).show();
        }
        return Integer.parseInt(s);
    }

    private int getSecondValueIn10Radix(String value, String radix){
        String s = "0";
        try {
            BigInteger a = new BigInteger(value, Integer.parseInt(radix));
             s = a.toString(10);
        }catch (NumberFormatException e){
            Toast.makeText(getApplicationContext(), "Неверное число для данной системы!", Toast.LENGTH_SHORT).show();
        }
        return Integer.parseInt(s);
    }

    private int getValueInTargetRadix(int result, String radix){
        String s = "0";
        try {
            BigInteger a = new BigInteger(String.valueOf(result), 10);
            s = a.toString(Integer.parseInt(radix));
        }catch (NumberFormatException e){
            Toast.makeText(getApplicationContext(), "Неверное число для данной системы!", Toast.LENGTH_SHORT).show();
        }
        return Integer.parseInt(s);
    }
}